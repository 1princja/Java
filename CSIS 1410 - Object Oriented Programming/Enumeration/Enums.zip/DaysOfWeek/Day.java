//CS1410
//source code from The Java Tutorials java.sun.com

public enum Day 
{
    SUNDAY, MONDAY, TUESDAY, WEDNESDAY, 
    THURSDAY, FRIDAY, SATURDAY 
}
